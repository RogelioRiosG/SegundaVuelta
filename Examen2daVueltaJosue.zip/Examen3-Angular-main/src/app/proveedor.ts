export interface Proveedor {
    id: number;
    name: string;
    "saldo": number,
    "estado": string,
    "type": "proveedor",
  }